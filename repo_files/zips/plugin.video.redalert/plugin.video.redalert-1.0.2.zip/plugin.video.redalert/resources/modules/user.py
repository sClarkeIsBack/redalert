import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnJlZGFsZXJ0')

name = b.b64decode('UmVkIEFsZXJ0')

host = b.b64decode('aHR0cDovL3JlZGFsZXJ0MTk3Ny5jb20=')

port = b.b64decode('ODA=')